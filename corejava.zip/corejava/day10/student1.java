package pkg1;

public class student1 {
	String name;int sid;int java;int selinium;
	String grade;
	double avg;

}
