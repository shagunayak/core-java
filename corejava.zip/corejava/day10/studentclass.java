package pkg1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class studentclass {
	

	public static student1 readexcel(int i)throws IOException
	{
		student1 s1=new student1();
		
		
			File f = new File("Downloads//student.xlsx");
			FileInputStream fls = new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fls);
			XSSFSheet sh= wb.getSheet("Sheet1");
			
			
				
			
			    XSSFRow row= sh.getRow(i);
    		    XSSFCell cell=row.getCell(1);
    		    
    		    
    		    	s1.name =cell.getStringCellValue();
    		    	 XSSFCell cell1=row.getCell(0);
    		    
    		    s1.sid=(int)cell1.getNumericCellValue();
    		    XSSFCell cell2=row.getCell(2);
    		    s1.java=(int)cell2.getNumericCellValue();
    		    XSSFCell cell3=row.getCell(3);
    		    s1.selinium=(int)cell3.getNumericCellValue();
    		  
				
			
				return s1;
				
		
	
	}
	public static void main(String args[])
	{
		ArrayList<student1> arr = new ArrayList<student1>(3);
		for(int i=1;i<4;i++)
		{
		arr.add(readexcel(i));

		}
		for(int i=0;i<3;i++)
		writeexcel(arr.get(i),(i+1));
	}
	public static void writeexcel(student1 item,int i)
	{
	try
	{
	File f = new File("Downloads//student.xlsx");
	FileInputStream fis = new FileInputStream(f);
	XSSFWorkbook wb= new XSSFWorkbook(fis);
	XSSFSheet sh= wb.getSheet("Sheet1");

	XSSFRow row1=sh.getRow(i);
	  XSSFCell cell_1=row1.createCell(4);
	  FileOutputStream fos1 = new FileOutputStream(f);
	  cell_1.setCellValue(item.avg);
	  XSSFCell cell_2=row1.createCell(5);
	  cell_2.setCellValue(item.grade);
	  
	  wb.write(fos1);



	  
	}
	catch (Exception e)
	{
	e.printStackTrace();
	}
	}
}
