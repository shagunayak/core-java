package pkg1;

public class pyramid {
	public static void main(String args[]){
		
	
	int num=9;
	for(int i=1;i<=4;i++)
	{
		for(int j=i;j<4;j++)
			System.out.print(" ");
		for(int j=1;j<=i;j++)
		{
			System.out.print(num+" ");
			
		}
		for(int j=i;j<4;j++)
			System.out.print(" ");
		
		num=num-2;
		System.out.println();
	}num=num+2;
	for(int i=1;i<4;i++)
	{ num=num+2;
		for(int j=i;j>=1;j--)
			System.out.print(" ");
		for(int j=i;j<4;j++)
		{
			System.out.print(num+" ");
			
		}
		for(int j=i;j>=1;j--)
			System.out.print(" ");
		
		
		System.out.println();
	}
	}
}
