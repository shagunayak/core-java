package pkg1;

public class divisionoperator {
public static void main(String args[])
{
	int a=32,x,y;
	x=a/10;
	System.out.println(x);
	y=a%10;
	System.out.println(y);


}

}
