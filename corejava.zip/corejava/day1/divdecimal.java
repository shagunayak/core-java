package pkg1;

public class divdecimal {
public static void main(String args[])
{
	
	float m=42.0f,n,p;
	n=m/10;
	p=m%10;
	System.out.println(n);
	System.out.println(p);
}

}
