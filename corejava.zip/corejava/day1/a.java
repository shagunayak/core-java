package pkg1;

public class a {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum=0;int c1=0;
		for(int i=2;i<30;i++){
			int c=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
					c=1;
			}
			
			if(c==0)
			{	sum=sum+i;
			System.out.print(i+"  ");
			    c1=c1++;
			}
			if (c1==10)
				break;
		}System.out.println("");
		System.out.println("sum of 10 prime numbers "+sum);

	}

}
