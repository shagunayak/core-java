package pkg1;

public class logic1 {
	public static void main(String args[]){
		
	
	int c=5;
	int a=10;
	int b=20;
	System.out.println(a<b);
	System.out.println(b>c);
	}
	

}
