package pkg1;

public class logic2 {
public static void main(String args[])
{
	
	int c=0;
	int a=10;
	int b=20;
	System.out.println((a>b)&&(a>c));
	System.out.println(!((a>b)||(a>c)));
	System.out.println(c&a);





}




}
