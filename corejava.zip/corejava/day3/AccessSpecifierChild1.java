package Package1;

public class AccessSpecifierChild1 extends AccessSpecifierPaernt 
{
	public void displayDetails()
	{
		AccessSpecifierPaernt a=new AccessSpecifierPaernt();
		System.out.println(a.a);
		//System.out.println(a.b); Access Specifier parent is not visible since b is private
		System.out.println(a.c);
		System.out.println(a.getD());
		}

}
