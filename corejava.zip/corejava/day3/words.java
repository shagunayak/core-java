package pkg1;

public class words {
	public static void main(String args[])
	{
		String s="i am learning core java.";
		
	}

}
