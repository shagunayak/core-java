package Package1;

public class AccessSpecifierPaernt 
{
	public int a=50;
	private int b=49;
	int c=98;
	private int d=96;
	public int getD() {
		return d;
	}
	public void setD(int d) {
		this.d = d;
	}

}
