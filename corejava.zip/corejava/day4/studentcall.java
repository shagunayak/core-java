package pkg1;

public class studentcall {

	/**
	 * @param args
	 */
	public static double greatavg(double avg1,double avg2)
	{
		if (avg1>avg2)
		{
			return avg1;
		}
		else
			
			return avg2;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      student shagun=new student();
      student anmol=new student();
      shagun.mark1=89;
      shagun.mark2=51;
      anmol.mark1=90;
      anmol.mark2=52;
      double avg1= shagun.average();
      double avg2= anmol.average();
      shagun.displaydetails();
      anmol.displaydetails();
      double greatavg1=greatavg(avg1,avg2);
      if (greatavg1==avg1)
		{
			System.out.println("shagun has greater average of "+avg1);
		}
		else
			
			System.out.println("anmol has greater average of "+avg2);
	}
      
	}


