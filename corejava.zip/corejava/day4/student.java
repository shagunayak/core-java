package pkg1;

public class student {
	String name;
	double mark1;
	double mark2;
	double avg;
	public double average()
	{
		avg=(mark1+mark2)/2;
		return avg;
	}
	public void displaydetails()
	{
		System.out.println("marks of subject1 "+mark1+" marks of subject2 "+ mark2 +" average = "+avg);
		
	}

	

}
