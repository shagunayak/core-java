package pkg1;

public class switchex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n=12;
		switch(n)
		{
		case 12:
			System.out.println("value is 12");
			
		case 5:
			System.out.println("value is 5");
			break;
		case 7:
			System.out.println("value is 7");
			break;
		default :
			System.out.println(" wrong value");
		
		
			
		}
	}

}
