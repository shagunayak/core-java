package pkg1;

public class object {

String color;
float len;
float breadth;
String brand;
public void call()
{
	System.out.println("mobile is calling");
	
}
public void msg(){
	System.out.println("mobile is msging");
	
}
public void displaydetails()
{
	System.out.println("colours ="+color+"length ="+len+"breadth ="+breadth);
}

	

}
