package pkg1;

public class objectcall {
	public static void main(String args[])
	{
		object smg=new object();
		smg.color="black";
		smg.len=6.2f;
		smg.brand="mi";
		smg.breadth=3.4f;
		smg.displaydetails();
		smg.call();
		smg.msg();
	}

}
