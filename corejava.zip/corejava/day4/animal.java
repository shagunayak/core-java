package pkg1;

public class animal {
 double weight;
 double age;
 double lifespan;
 String colour;
 String diet;
 String habitat;
 String sex;
 public void eat()
 {
	 System.out.println("animal is eating");
	 
 }
 public void reproduce()
 {
	 System.out.println("animals reproduce");
 }
}
