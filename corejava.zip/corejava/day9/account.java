package pkg1;

public class account {
	 String accountname;
		int accountno;
		int accountbal;
		double int_rate;
		public String getDetails()
		{
			return ("Account Number: "+accountno+" Account Balance: "+accountbal+"Interest Rate"+int_rate);
		}
		public void depositAmount(float amt)
		{
			accountbal+=amt;
			System.out.println(accountname+" have successfully deposited an amount of "+amt);
		}
	public void calculateInterest()
	{
		
		System.out.println("Interest on the given amount will be for "+accountname+" is "+(accountbal*(int_rate/100)));
		
	}
	public void checkBalance()
	{
		System.out.println("Available Balance for "+accountname+" is "+accountbal);
	}
	

	

	

}
