package pkg1;

public class fdaccount extends account{
	public fdaccount(	int accountno,int accountbal,double int_rate,String accountname)
	 {
		this.accountname=accountname;
		this.accountbal=accountbal;
		this.accountno=accountno;
		this.int_rate=int_rate;
		public void calculatematurity() 
		{
			System.out.println("maturity amount = "+ (accountbal+(accountbal*int_rate/100)));
		}
		
	}
}
