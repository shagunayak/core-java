package pkg1;

public class fibonacci {

	public static void main(String args[])
	{
		int n=5;int f1=0;int f2=1;int f3=0;
		System.out.print(f1+" "+f2+" ");
		for(int i=1;i<=5;i++)
		{
           f3=f2+f1;
           System.out.print(f3+" ");
           f1=f2;
           f2=f3;
		}
	    
	}
}
