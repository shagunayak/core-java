package pkg1;

public class divby7_11 {
	public static void main(String args[])
	{
		int sum=0;
		for(int i=1;i<=200;i++)
		{
			if((i%7==0)&&(i%11==0))
			{ System.out.println( i+ " ");
			 sum =sum+i;
			}
		}
		System.out.println("sum of numbers = "+ sum);
	}

}
