package pkg1;

public class overloading {

	public static int add (int x, int y)
	{
		return(x+y);
	}
	public static int add (int x, int y,int z)
	{
		return(x+y+z);
	}
	public static float add (float x, float y)
	{
		return(x+y);
	}
	public static float add (float x, float y,float z)
	{
		return(x+y+z);
		
	}
	public static void main(String args[])
	{
		System.out.println(add(3,4));
		System.out.println(add(3,4,5));System.out.println(add(3.2f,4.5f));System.out.println(add(3.2f,4.5f,6.0f));
	}
}
