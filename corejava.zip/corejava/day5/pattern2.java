package pkg1;

public class pattern2 {
	public static void main(String args[])
	{
	
	
			
			for(int j=1;j<=3;j++)
			{	for(int i=1;i<=j;i++)
				System.out.print(j);
			System.out.println();
			
			}
	}

}
