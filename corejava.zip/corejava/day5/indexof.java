package pkg1;

public class indexof {
	public static void main(String args[])
	{
		String s="i am learning java";String s1;
				int l=s.length();
				for(int i=0;i<l;)
				{
					s1="";
					int j=s.indexOf(' ',i);

					s1= s.substring(i,j);
			        System.out.println(s1);
					if(j==s.lastIndexOf(' '))
					{
						i=j+1;
						j=s.length();
						s1= s.substring(i,j);
				        System.out.println(s1);
						
						}
					i=j+1;
				}
	}

}
