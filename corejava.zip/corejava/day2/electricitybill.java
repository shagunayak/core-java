package pkg1;

public class electricitybill {

	public static void main(String args[])
	{ double sum=0.0f;
		int unit=500;
		if(unit <=100)
			sum=sum+(unit*1.5);
		else if((unit>100)&&(unit<=200))
			sum=sum+(100*1.5)+(unit-100)*2;
		else if((unit>200)&&(unit<=250))
			sum=sum+(100*1.5)+(100*2.0)+(unit-200)*2.5;
		else
			sum=sum+(100*1.5)+(100*2.0)+(50*2.5)+(unit-250)*4.0;
		System.out.println(sum);
		
		
		
		
	}
}
