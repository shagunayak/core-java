package pkg1;

public class array {
	public static void main(String args[])
	{
		int sum=0;double avg=0.0;
		int[] m={91,6,65,89,20};
		for(int i=0;i<=4;i++)
		{
			sum=sum+m[i];
		}
		avg=sum/5;
		for(int i=0;i<=4;i++)
		{
			if(m[i]>=avg)
				System.out.println(m[i]);
		}
	}

}
