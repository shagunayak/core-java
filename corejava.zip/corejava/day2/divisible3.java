package pkg1;

public class divisible3 {
	public static void main(String args[])
	{
		int rem=0;int sum=0;
		
		for(int i=10;i<=30;i++)
		{
			rem=i%3;
			if(rem==0)
			{
				System.out.println(i);
				sum=sum+i;
			}
		}
		System.out.println(sum);
			
	}

}
