package pkg1;
import java.util.*;

public class marks {
public static void main(String args[])
{
	Scanner s=new Scanner(System.in);
	int m1,m2,m3,m4;double avg; double highest=0.0;String name="";String tname="";
	for(int i=1;i<=3;i++)
	{
		System.out.println("enter the name of student");
		name=s.next();
		System.out.println("enter the marks of 4 subject of student "+name);
		m1=s.nextInt();
		m2=s.nextInt();m3=s.nextInt();m4=s.nextInt();
		avg=(m1+m2+m3+m4)/4;
		System.out.println(" marks of "+name+" is "+avg);
		if (avg>highest)
		{	highest=avg;
		    tname=name;
		}
		
	}
	
	System.out.println("the marks of the topper "+ tname+" is "+highest);
	
	
}
}
