package pkg1;

public class array2 {
	public static void main(String args[])
	{
		int [] a={21,15,34,91,50,16,44,65,0,23,42};
		for( int i=0;i<=10;i++)
		{ 
			for(int j=1;j<=10;j++)
			{
				if(a[i]+a[j]==65)
				{
					System.out.println(a[i]+"+" +a[j]+" = 65");
				}
			}
		}
	}

}
