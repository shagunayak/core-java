package pkg1;

public class result {
	public static void main(String args[])
	{
		float marks=75.0f;
		if(marks>=75)
			System.out.println("FCD");
		else if(marks >=60)
			System.out.println("FC");
		else if(marks >=50)
			System.out.println("pc");
		else
			System.out.println("f");
		
		
	}

}
