package pkg1;

public class type {
	public static void main(String ARGS[])
	{
		String s="10",s2="20";
		System.out.println(s+s2);
		int a,b;
		a=Integer.parseInt(s);
		b=Integer.parseInt(s2);
		System.out.println(a+b+"hey"+a+b);
		
		
	}

}
