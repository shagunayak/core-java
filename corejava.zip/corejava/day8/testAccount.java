package pkg1;

public class testAccount {
	public static void main(String args[])
	{
		sbaccount Ram=new sbaccount(123,0,4,"Ram");
		sbaccount Shyam=new sbaccount(124,0,4,"Shyam");
		Ram.depositAmount(25000);
		Shyam.depositAmount(35000);
		Ram.calculateInterest();
		Shyam.calculateInterest();
		fdaccount Prashant =new fdaccount(125,0,6,"Prashant");
		Prashant.depositAmount(20000);
		Prashant.calculateInterest();
		Ram.checkBalance();
		Ram.withdrawAmount(1000);
		Ram.checkBalance();
		Ram.withdrawAmount(23600);
		
		
		
	}
}
