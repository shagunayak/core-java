package pkg1;

public class accountversion2 {
	int accountno;
	float accountbal;
	float int_rate;
	public accountversion2(int accountno)
	{
		this.accountno=accountno;
	
	}
	public accountversion2(int accountno,float accountbal ,float int_rate )
	{
		this.accountno=accountno;
		this.accountbal=accountbal;
		this.int_rate=int_rate;
	}
	public void get_accountdetails(){}

}
