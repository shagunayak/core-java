package pkg1;

public class ExceptionExample 
{
	public static void main(String args[])
	{
		int a=10;
		int b=0;
		int[] array=new int[5];
		try
		{
			array[5]=5;;
			
			
		}
		/*catch(ArrayIndexOutOfBoundsException aa)
		{
			aa.printStackTrace();
		}*/
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		catch (Exception e)
		{
			System.out.println("Specific exception is not catched");
			
			
		}
	}

}
