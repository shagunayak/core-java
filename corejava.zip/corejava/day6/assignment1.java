package pkg1;

import java.io.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class assignment1 {
		public static void main(String args[])
		{int c=0,c1=0,c2=0;
			try
			{ 
				for(int i=0;i<=9;i++)
				{
					int val= readexcel(i);
					boolean f= prime(val);
					String s="";
					
					if(f==true)
					{ s="prime";
					
					 writeexcel(c,s,val);
					 c++;
					 
					}
						  
					else
					{
						if(val%2==0)
							{s="even";writeexcel(c1,s,val); c1++;}
						else
							{ s="odd";writeexcel(c2,s,val);c2++;}
							
					}
					
					
				}
				
				}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		public static int readexcel(int r)
		{ int i=0;
			try
			{
				File f = new File("C:\\Users\\Shagun.nayak\\Desktop\\file.xlsx");
				FileInputStream fls = new FileInputStream(f);
				XSSFWorkbook wb= new XSSFWorkbook(fls);
				XSSFSheet sh= wb.getSheet("numbers");
				XSSFRow row= sh.getRow(r);
	    		XSSFCell cell=row.getCell(0);
	    		double i1=cell.getNumericCellValue();
	    		  i=(int)i1;
	    		  return i;
	    		  
			}
			catch (Exception e)
			{
				e.printStackTrace();
				return i;
				
			}
			
			
			
		}
		public static void writeexcel(int r,String s,int d)
		{
			try
			{
				File f = new File("C:\\Users\\Shagun.nayak\\Desktop\\file.xlsx");
				FileInputStream fls = new FileInputStream(f);
				XSSFWorkbook wb= new XSSFWorkbook(fls);
				XSSFSheet sh= wb.getSheet(s);
				XSSFRow row1= sh.createRow(r);
	    		  XSSFCell cell1=row1.createCell(0);
	    		  cell1.setCellValue(d);
	    		  FileOutputStream fos1 = new FileOutputStream(f);
	    		  wb.write(fos1);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		public static boolean prime(int d)
		{int c=0;
			for(int i=2;i<d;i++)
			{
				 if(d%i==0)
				{c=1;break;}
			}
				
				if(c==0)
				return(true);
				else
			    return(false);
		}
			
}
