package pkg1;
import java.util.*;

public class vowel {
	public static void main(String args[])
	{
	
		
		
	}

}
