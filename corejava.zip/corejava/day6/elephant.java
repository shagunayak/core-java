package pkg1;

public class elephant {
	int no_of_tusk;
	double length;

}
