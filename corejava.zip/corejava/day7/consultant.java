package pkg1;

public class consultant extends employee {
	int totalhrsworked;
	public int calculatesalary()
	{
		int sal;
		sal=totalhrsworked*rateperunit;
		return sal;
		
	}
	consultant(int totalhrs,int eid,String ename,int rateperunit)
	{
		super(eid,ename,rateperunit);
		this.totalhrsworked=totalhrs;
		
	}

}
