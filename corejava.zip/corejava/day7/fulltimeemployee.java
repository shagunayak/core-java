package pkg1;

public class fulltimeemployee extends employee {
	int totaldaysworked;
	public int calculatesalary()
	{
		int sal;
		sal=totaldaysworked*rateperunit;
		return sal;
	}
	fulltimeemployee(int totaldays,int eid,String ename,int rateperunit)
	{
		super(eid,ename,rateperunit);
		this.totaldaysworked=totaldays;
		
	}

}
