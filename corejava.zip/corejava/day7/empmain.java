package pkg1;

public class empmain {
	public static void main(String args[])
	{
		consultant ob=new consultant(22,345,"shagun",50);
		System.out.println(ob.calculatesalary());
		fulltimeemployee ob1=new fulltimeemployee(15,700,"prachi",60);
		System.out.println(ob1.calculatesalary());
		
	}

}
