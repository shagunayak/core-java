package pkg1;

import java.io.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {
      public static void main (String args[])
      {
    	  try
    	  {
    		  File f = new File("C:\\Users\\Shagun.nayak\\Desktop\\file2.xlsx");
    		  FileInputStream fls = new FileInputStream(f);
    		  XSSFWorkbook wb= new XSSFWorkbook(fls);
    		  XSSFSheet sh= wb.getSheet("Sheet1");
    		  XSSFRow row= sh.getRow(0);
    		  XSSFCell cell=row.getCell(0);
    		  String s= cell.getStringCellValue();
    		  System.out.println("data : "+s);
    		  FileOutputStream fos = new FileOutputStream(f);
    		  cell.setCellValue("noida");
    		  wb.write(fos);
    		  XSSFRow row1= sh.createRow(2);
    		  XSSFCell cell1=row1.createCell(0);
    		  cell1.setCellValue("globallogic");
    		  
    		  FileOutputStream fos1 = new FileOutputStream(f);
    		  wb.write(fos1);
    				  
    	  }
    	  catch (IOException e)
    	  {
    		  e.printStackTrace();
    	  }
    	  
      }

}
