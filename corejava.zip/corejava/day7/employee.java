package pkg1;

public abstract class employee {
	int eid;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getRateperunit() {
		return rateperunit;
	}
	public void setRateperunit(int rateperunit) {
		this.rateperunit = rateperunit;
	}
	String ename;
	int rateperunit;
	abstract int calculatesalary();

	employee(int eid1,String ename1, int rate)
	{
		this.eid=eid1;
		this.ename=ename1;
		this.rateperunit=rate;
	}

}
