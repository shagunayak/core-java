package pkg1;



public class seriesprime 
{
public static void main(String []args)
{
int a[] = new int[31];
int prime[]=new int[31];
for(int i=2;i*i<=30;i++)
{
for(int j=i*2;j<=30;j+=i)
a[j]=1;
}
int x=0;
for(int i=2;i<=30;i++)
if(a[i]==0)
prime[x++]=i;
int z=1;
for(int i=0;i<10;i++)
{
if(z%3==0)
{
System.out.print(prime[i]+prime[i+1]+ " ");
i++;
}
else
System.out.print(prime[i]+" ");
z++;
}

}
}

